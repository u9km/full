#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:23:54 2025
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_LocalizeRes_type.BP_STRUCT_LocalizeRes_type
// 0x0010
struct FBP_STRUCT_LocalizeRes_type
{
	struct FString                                     TextValue_0_4D37165A410D67320AF278A1C1028E4F;             // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

