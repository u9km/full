#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:23:53 2025
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_BigSegmentUpConfig_type.BP_STRUCT_BigSegmentUpConfig_type
// 0x0058
struct FBP_STRUCT_BigSegmentUpConfig_type
{
	struct FString                                     HighLevelDeviceAnimPath_0_703E7C0074FB67A670B77DB604C5CFF8;// 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_1_068648C01D06091F1B6E47800634E474;                    // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FString                                     VideoPath_4_7CE7A68040FD463430D035E10A0A3E38;             // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     SegmentUpAudioPath_6_3A6BAB4046E51B1B018362F70A65D778;    // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     SettledAudioPath_7_556EFA8033B134C021A93177054ADA98;      // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     SegStarIconPath_8_2A41994011E0ADD57F9C308707C7BD88;       // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

