#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:23:59 2025
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_LoginTypeListCfg_type.BP_STRUCT_LoginTypeListCfg_type
// 0x0074
struct FBP_STRUCT_LoginTypeListCfg_type
{
	int                                                vk_1_4D150F800FF7457E47A4BBF80A4FE97B;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                facebook_2_6B5EE5C01DC298954FEE67540DD47E2B;              // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                guest_3_1C3541407226F6AB70CC647C0E851854;                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	struct FString                                     RegionDesc_5_52ADF00018ED72103BEE907D01C99D03;            // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                twitter_6_799D3C006ADF4D8C6E24EE0600844452;               // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                line_7_2BC341400AC147413DEA00130FE99605;                  // 0x0024(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     ID_8_09129A803217EE9447A481C60A4FEA64;                    // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                hms_10_25A7A9407D8C1CB161DD507B04FE86E3;                  // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
	struct FString                                     Language_11_6FFD20403D96047D07ADE9370E015C45;             // 0x0040(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                index_12_6814DD4001A91F8370ECD0960E85EE38;                // 0x0050(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                discord_13_754FF1405DEEB00D01CE6D8F02AD7804;              // 0x0054(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                bgbg_14_06FAFBC051FD0AE715C19A410FE837C7;                 // 0x0058(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                noschat_15_0BEC93406558B7AF3331598100CD6024;              // 0x005C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                scan_16_7CA0C0806794498C3DC63F9F0FE9233E;                 // 0x0060(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                gamecenter_17_5F8E5E0026811E7431EA532C047434B2;           // 0x0064(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                googleplay_18_1BB54400378EFC7E36814EAF03C4F299;           // 0x0068(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                whatsapp_19_13AB91407BFB107B5E74F1C404C47110;             // 0x006C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                tiktok_20_64E2BCC01E36082913ABCFAC091666BB;               // 0x0070(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

