#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:23:57 2025
 
namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass BattleItemHandle_VirtualItem.BattleItemHandle_VirtualItem_C
// 0x0000 (0x0138 - 0x0138)
class UBattleItemHandle_VirtualItem_C : public UBattleItemHandleBase
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BattleItemHandle_VirtualItem.BattleItemHandle_VirtualItem_C");
		return pStaticClass;
	}

};


}

