#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:23:59 2025
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_LoginHideCfg_type.BP_STRUCT_LoginHideCfg_type
// 0x0020
struct FBP_STRUCT_LoginHideCfg_type
{
	struct FString                                     Channel_0_7A33B4804EECE9DA2882EE5B0C6EAD0C;               // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<struct FName>                               Rule_an_1_760777C07100CED14B793A7D0C488CDE;               // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

