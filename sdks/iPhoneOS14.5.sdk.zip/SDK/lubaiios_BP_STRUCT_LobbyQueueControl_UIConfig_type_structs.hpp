#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:23:57 2025
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_LobbyQueueControl_UIConfig_type.BP_STRUCT_LobbyQueueControl_UIConfig_type
// 0x0041
struct FBP_STRUCT_LobbyQueueControl_UIConfig_type
{
	int                                                BigType_0_40DE1EC0180FAF994DDBA0C40ED48D05;               // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               IsUnlimited_1_22E86B802FA92E4A7725A5590F96AE24;           // 0x0004(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0005(0x0003) MISSED OFFSET
	struct FString                                     KeyName_2_22737C401026D429084E417407E68B45;               // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     LobbyType_3_5318D8400C468EBB754620C40053D515;             // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Param_4_2BB60E004F65CFE82D1A0EC80D70A0BD;                 // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                SmallType_5_27AD988016F05D5A404F5ED900FC4045;             // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                UIKey_6_6693C38003A294E42D499D760D800909;                 // 0x003C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               UIStackCheck_7_1724EE40618D04232488F13A0E05CD3B;          // 0x0040(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

