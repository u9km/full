#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:23:49 2025
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct CommonGameFeatures.RepControlGroupData
// 0x0050
struct FRepControlGroupData
{
	TMap<int64_t, int>                                 RepControlMap;                                            // 0x0000(0x0050) (ZeroConstructor)
};

}

