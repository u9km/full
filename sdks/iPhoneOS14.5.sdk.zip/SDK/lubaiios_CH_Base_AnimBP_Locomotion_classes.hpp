#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:23:54 2025
 
namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// AnimBlueprintGeneratedClass CH_Base_AnimBP_Locomotion.CH_Base_AnimBP_Locomotion_C
// 0x24A8 (0x31B8 - 0x0D10)
class UCH_Base_AnimBP_Locomotion_C : public UAnimInstanceLocomotion
{
public:
	struct FPointerToUberGraphFrame                    UberGraphFrame;                                           // 0x0D10(0x0008) (Transient, DuplicateTransient)
	struct FAnimNode_Root                              AnimGraphNode_Root_332A0343461DB0582EBA02BCAD3EF8B5;      // 0x0D18(0x0050)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_DA7023C24B2D25EEE7207999A7521ACD;// 0x0D68(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_5BE2D42C4DCD64C6F94956A63D026381;// 0x0DB0(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_E8B56A824309F177E1609A8FC4537C24;// 0x0DF8(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_3F6B7B6241ED58EB8A6E5883968BA988;// 0x0E40(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_D3DF1E8C4255A8A00E3E018E54B3BF57;// 0x0E88(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_B418056448558E02C7513189B30A71C8;// 0x0ED0(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_43703A7B43CDD6FD968470A4CD381441;// 0x0F18(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_C1E0978144C080F69A53F3A77D21C9AF;// 0x0F60(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_A136A29947AA671EAF68AD8D163F908C;// 0x0FA8(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_46B3DF07499C16F35810F2BB123F4FAD;// 0x0FF0(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_CF6258D24DECA6C0BEA75EAFF3D783F4;// 0x1038(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_3B0E1AC7422CBB0CD15CB3A25B201F14;// 0x1080(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_4D01046F425FD92DFF6E15A00D4D2E65;// 0x10C8(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_40FCC45840891CA4710F8BAF1516C913;// 0x1110(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_C9BC99B84BBAE7C24833EBAB2460BA6E;// 0x1158(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_27EADA3942E848C60A1602A35DBB2A5C;// 0x11A0(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_3259213742C00384412654A187E1404D;// 0x11E8(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_296B91B5499EDB6DEC97C29687773B86;// 0x1230(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_C64EFC4E400852FEB1DDA0BDA1EBA7FD;// 0x1278(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_D0AD41374783493AEA002CB59484E7DC;// 0x12C0(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_521157AC403BBBD3D5535CAEA7CA1A68;// 0x1308(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_950B64354F6A5F2D2B99AABDCF5B57AC;// 0x1350(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_D818E596423947C8506878A31A853F72;// 0x1398(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_7422A1224A750926AAE3E18E84E1B339;// 0x13E0(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_CD849232469DB4922127CF80970771A7;// 0x1428(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_E83E3ABD443DCD5560079B8C7B87B046;// 0x1470(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_C323AA544D827B9536D96CA1EBCEF3F6;// 0x14B8(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_AD60938B472241192679EFB5C95F424D;// 0x1500(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_B83D06F14F7763EEDCCC90BCDE107D90;// 0x1548(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_7795601B40CCA1751334BA929AA0D877;// 0x1590(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_8D9DC29C4E60C025FC9F3AB8A65E684A;// 0x15D8(0x0048)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_7AD195734AC54CD31B3660811EDFBF9C;// 0x1620(0x0050)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_AEA1CBA3472DD15634C624AD0DBAC446;// 0x1670(0x0070)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_8753ABE04351BC34C92174918BB25735;// 0x16E0(0x0070)
	struct FAnimNode_BlendListByBool                   AnimGraphNode_BlendListByBool_083A0E694DD4E87239209D9232B73B9A;// 0x1750(0x00D0)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_E43ABC33424B2BCEA2C8CAABDD8088F2;// 0x1820(0x0050)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_AD3C547F402AE732A014DAB7136B6645;// 0x1870(0x0070)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_F4E91B2C4AD6350E62FA5594A103122B;// 0x18E0(0x0070)
	struct FAnimNode_BlendListByBool                   AnimGraphNode_BlendListByBool_B3BADA8D48425268CD875BB542C533E7;// 0x1950(0x00D0)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_53C4E96A4C4AFF3792E781BA8A88D4EB;// 0x1A20(0x0050)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_8D3E57E7402DEC10CED1A693E6B41B5F;// 0x1A70(0x0070)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_B911DAEB4EC32C285C1F50AC49F4A755;// 0x1AE0(0x0050)
	struct FAnimNode_SequenceEvaluator                 AnimGraphNode_SequenceEvaluator_90197B82409169623703A4A4866D0CDF;// 0x1B30(0x0070)
	struct FAnimNode_LayeredBoneBlend                  AnimGraphNode_LayeredBoneBlend_18349BF2490268F7A90B04A6983B9C5E;// 0x1BA0(0x00E8)
	struct FAnimNode_BlendListByBool                   AnimGraphNode_BlendListByBool_BF8E9C384E714B6B2DE9D288E3E5DFCE;// 0x1C88(0x00D0)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_6D4EE43547BF74E252C480A219ED3F86;// 0x1D58(0x0070)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_372323BB46568C131F62C292471E6B15;// 0x1DC8(0x0050)
	struct FAnimNode_BlendSpacePlayer                  AnimGraphNode_BlendSpacePlayer_7FCDB335445D55C19D0858A4BA9A3118;// 0x1E18(0x0128)
	struct FAnimNode_BlendSpacePlayer                  AnimGraphNode_BlendSpacePlayer_ECB8B56E43993BA18965718AB8CBF2DF;// 0x1F40(0x0128)
	struct FAnimNode_BlendListByBool                   AnimGraphNode_BlendListByBool_112BC5E14A659CC892ACB4B9DC136D4E;// 0x2068(0x00D0)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_68BFB0674AC0FCA847B179A7BF16FFEE;// 0x2138(0x0050)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_78E7C37D4598ED776ACE458EF7EFC462;// 0x2188(0x0070)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_90579CFF42A27AE6C18576B0CFD67FF3;// 0x21F8(0x0070)
	struct FAnimNode_BlendListByBool                   AnimGraphNode_BlendListByBool_EAE8524249B190BE2CE2A1BA81A88420;// 0x2268(0x00D0)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_F3F4BCB54FD3F69DF3491E8407377B4E;// 0x2338(0x0050)
	struct FAnimNode_BlendSpacePlayer                  AnimGraphNode_BlendSpacePlayer_4E0BC3E141023185A062DDBEE1608E11;// 0x2388(0x0128)
	struct FAnimNode_BlendSpacePlayer                  AnimGraphNode_BlendSpacePlayer_DB0A9F7243300012A49D0D8E5D4F92DE;// 0x24B0(0x0128)
	struct FAnimNode_BlendListByBool                   AnimGraphNode_BlendListByBool_5F02101F4B1921DFECBAEFA52E322CDB;// 0x25D8(0x00D0)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_36A609A548C6A7F66C30EA84870FC93D;// 0x26A8(0x0050)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_E7B9FFB543D1388C0518C6964B6F4E1C;// 0x26F8(0x0070)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_A0850F344C9D58724F7B4FA73C9A38C1;// 0x2768(0x0070)
	struct FAnimNode_BlendListByBool                   AnimGraphNode_BlendListByBool_D33DE8924F3A1B51607280A5DA7B2496;// 0x27D8(0x00D0)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_33039AA845F425B302C0A3A5811A9E88;// 0x28A8(0x0050)
	struct FAnimNode_BlendSpacePlayer                  AnimGraphNode_BlendSpacePlayer_124B6BCA40DDD5A40D44AFBFC6AA374A;// 0x28F8(0x0128)
	struct FAnimNode_BlendSpacePlayer                  AnimGraphNode_BlendSpacePlayer_2A02796E45C21CCCE3D0FD9B07F0D202;// 0x2A20(0x0128)
	struct FAnimNode_LayeredBoneBlend                  AnimGraphNode_LayeredBoneBlend_200E959048836B40CC4C0EB830E4A91C;// 0x2B48(0x00E8)
	struct FAnimNode_BlendSpaceEvaluator               AnimGraphNode_BlendSpaceEvaluator_218EFD174719FA633B1969821A79B6D0;// 0x2C30(0x0130)
	struct FAnimNode_BlendListByBool                   AnimGraphNode_BlendListByBool_6C97DADF44BA8A5C4A621B8E31968E2B;// 0x2D60(0x00D0)
	struct FAnimNode_BlendListByBool                   AnimGraphNode_BlendListByBool_78EBE7BE41A4F80DAFE954B0E7960670;// 0x2E30(0x00D0)
	struct FAnimNode_BlendSpacePlayer                  AnimGraphNode_BlendSpacePlayer_0BD951B64DA1A3AD751750AB21F16374;// 0x2F00(0x0128)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_10011BCC440387315791C68B7F822ACF;// 0x3028(0x0050)
	struct FAnimNode_StateMachine                      AnimGraphNode_StateMachine_06B0362B408D80188584F1BA6DCC6D04;// 0x3078(0x00D8)
	struct FAnimParamVector                            AnimVelocity;                                             // 0x3150(0x0018) (Edit, BlueprintVisible)
	struct FAnimParamEnum                              AnimPoseType_1;                                           // 0x3168(0x0010) (Edit, BlueprintVisible)
	struct FAnimParamBool                              MovementChanged;                                          // 0x3178(0x0010) (Edit, BlueprintVisible, DisableEditOnInstance)
	struct FAnimParamBool                              bMoveChgAndNotSwitchingPose;                              // 0x3188(0x0010) (Edit, BlueprintVisible, DisableEditOnInstance)
	struct FAnimAssetBlendSpace                        BSMoveStandDest;                                          // 0x3198(0x0010) (Edit, BlueprintVisible, DisableEditOnInstance)
	struct FAnimParamEnum                              EWeaponType;                                              // 0x31A8(0x0010) (Edit, BlueprintVisible, DisableEditOnInstance)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("AnimBlueprintGeneratedClass CH_Base_AnimBP_Locomotion.CH_Base_AnimBP_Locomotion_C");
		return pStaticClass;
	}


	void IsFallingReload(bool* Ret);
	bool ShouldPlayFootSound();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_3259213742C00384412654A187E1404D();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_40FCC45840891CA4710F8BAF1516C913();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_296B91B5499EDB6DEC97C29687773B86();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_C64EFC4E400852FEB1DDA0BDA1EBA7FD();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_D0AD41374783493AEA002CB59484E7DC();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_521157AC403BBBD3D5535CAEA7CA1A68();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_950B64354F6A5F2D2B99AABDCF5B57AC();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_27EADA3942E848C60A1602A35DBB2A5C();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_D818E596423947C8506878A31A853F72();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_7422A1224A750926AAE3E18E84E1B339();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_CD849232469DB4922127CF80970771A7();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_E83E3ABD443DCD5560079B8C7B87B046();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_C323AA544D827B9536D96CA1EBCEF3F6();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_AD60938B472241192679EFB5C95F424D();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_B83D06F14F7763EEDCCC90BCDE107D90();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_7795601B40CCA1751334BA929AA0D877();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_4D01046F425FD92DFF6E15A00D4D2E65();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_8D9DC29C4E60C025FC9F3AB8A65E684A();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_SequencePlayer_AEA1CBA3472DD15634C624AD0DBAC446();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_SequencePlayer_8753ABE04351BC34C92174918BB25735();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_BlendListByBool_083A0E694DD4E87239209D9232B73B9A();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_3B0E1AC7422CBB0CD15CB3A25B201F14();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_CF6258D24DECA6C0BEA75EAFF3D783F4();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_SequencePlayer_AD3C547F402AE732A014DAB7136B6645();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_SequencePlayer_F4E91B2C4AD6350E62FA5594A103122B();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_BlendListByBool_B3BADA8D48425268CD875BB542C533E7();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_46B3DF07499C16F35810F2BB123F4FAD();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_SequencePlayer_8D3E57E7402DEC10CED1A693E6B41B5F();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_A136A29947AA671EAF68AD8D163F908C();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_BlendListByBool_BF8E9C384E714B6B2DE9D288E3E5DFCE();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_SequencePlayer_6D4EE43547BF74E252C480A219ED3F86();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_C1E0978144C080F69A53F3A77D21C9AF();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_BlendSpacePlayer_7FCDB335445D55C19D0858A4BA9A3118();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_BlendSpacePlayer_ECB8B56E43993BA18965718AB8CBF2DF();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_BlendListByBool_112BC5E14A659CC892ACB4B9DC136D4E();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_43703A7B43CDD6FD968470A4CD381441();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_SequencePlayer_78E7C37D4598ED776ACE458EF7EFC462();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_SequencePlayer_90579CFF42A27AE6C18576B0CFD67FF3();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_BlendListByBool_EAE8524249B190BE2CE2A1BA81A88420();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_B418056448558E02C7513189B30A71C8();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_BlendSpacePlayer_4E0BC3E141023185A062DDBEE1608E11();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_BlendSpacePlayer_DB0A9F7243300012A49D0D8E5D4F92DE();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_BlendListByBool_5F02101F4B1921DFECBAEFA52E322CDB();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_D3DF1E8C4255A8A00E3E018E54B3BF57();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_3F6B7B6241ED58EB8A6E5883968BA988();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_SequencePlayer_E7B9FFB543D1388C0518C6964B6F4E1C();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_SequencePlayer_A0850F344C9D58724F7B4FA73C9A38C1();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_BlendListByBool_D33DE8924F3A1B51607280A5DA7B2496();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_E8B56A824309F177E1609A8FC4537C24();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_BlendSpacePlayer_124B6BCA40DDD5A40D44AFBFC6AA374A();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_BlendSpacePlayer_2A02796E45C21CCCE3D0FD9B07F0D202();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_BlendSpaceEvaluator_218EFD174719FA633B1969821A79B6D0();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_BlendListByBool_6C97DADF44BA8A5C4A621B8E31968E2B();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_BlendListByBool_78EBE7BE41A4F80DAFE954B0E7960670();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_BlendSpacePlayer_0BD951B64DA1A3AD751750AB21F16374();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_5BE2D42C4DCD64C6F94956A63D026381();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_DA7023C24B2D25EEE7207999A7521ACD();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_Locomotion_AnimGraphNode_TransitionResult_C9BC99B84BBAE7C24833EBAB2460BA6E();
	void AnimNotify_SpawnRFootprint();
	void AnimNotify_SpawnLFootprint();
	void AnimNotify_PlayFallSound();
	void AnimNotify_PlayShellDropFX();
	void AnimNotify_PlayMagOUTSound();
	void AnimNotify_PlayMagINSound();
	void AnimNotify_PlayBoltSound();
	void AnimNotify_PlayChangeMagazineSound();
	void AnimNotify_PlayLoadBulletSound();
	void AnimNotify_PlayCrawlSound();
	void AnimNotify_PlaySquatSound();
	void AnimNotify_PlayRunSound();
	void AnimNotify_PlayWalkSound();
	void AnimNotify_LandHardCameraShake();
	void AnimNotify_LandCameraShake();
	void AnimNotify_LeaveSwitchPoseState();
	void AnimNotify_EnterSwitchPoseState();
	void ExecuteUbergraph_CH_Base_AnimBP_Locomotion(int EntryPoint);
};


}

