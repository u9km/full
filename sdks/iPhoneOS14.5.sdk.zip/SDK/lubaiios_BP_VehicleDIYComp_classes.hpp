#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:24:02 2025
 
namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass BP_VehicleDIYComp.BP_VehicleDIYComp_C
// 0x0000 (0x0558 - 0x0558)
class UBP_VehicleDIYComp_C : public UVehicleAvatarDIYComponent
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_VehicleDIYComp.BP_VehicleDIYComp_C");
		return pStaticClass;
	}

};


}

