#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:23:58 2025
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_ItemAttrs_type.BP_STRUCT_ItemAttrs_type
// 0x0011
struct FBP_STRUCT_ItemAttrs_type
{
	bool                                               CannotManualDrop_0_0E61A2402E96D7E519F01EB60A948770;      // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	int                                                Id_1_3F8638004A8D0C9628CCDB940E749B64;                    // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               NotAddInTombBox_2_089BB7C052749B513D7FACBB06702BD8;       // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               RespawnNotDrop_3_715016400C714305540785CB07BAA120;        // 0x0009(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               CanCarryInBattle_4_4EF29640398A73A971C37BCB0F9A2E95;      // 0x000A(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               CannotMoveToVehicleBackpack_5_3A737000186CA4D4320F056F01D2466B;// 0x000B(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              InTombBoxProbability_f_7_55637AC02F17608F23BA3B6A0B2B33E6;// 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               TransformNotDrop_8_12F74D40630639D91D9A5A34066FF870;      // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

