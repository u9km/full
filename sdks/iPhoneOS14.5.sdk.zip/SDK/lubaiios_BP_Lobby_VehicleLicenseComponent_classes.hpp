#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:24:03 2025
 
namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass BP_Lobby_VehicleLicenseComponent.BP_Lobby_VehicleLicenseComponent_C
// 0x0000 (0x0308 - 0x0308)
class UBP_Lobby_VehicleLicenseComponent_C : public UVehicleLicenseNumberComponent
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_Lobby_VehicleLicenseComponent.BP_Lobby_VehicleLicenseComponent_C");
		return pStaticClass;
	}

};


}

