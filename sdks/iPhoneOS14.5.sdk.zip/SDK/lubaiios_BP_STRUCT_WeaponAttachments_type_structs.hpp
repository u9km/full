#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:23:58 2025
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_WeaponAttachments_type.BP_STRUCT_WeaponAttachments_type
// 0x00B8
struct FBP_STRUCT_WeaponAttachments_type
{
	int                                                KeyID_12_DE29BA8D4D52E79C09ECD792B3E5AF59;                // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                BulletID_16_836CF1DA41D9B5D6B2A048B65ABF9EA7;             // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ProposeBulletNum_17_776C3F00316F0B260271992A098E22ED;     // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                AIMinAttackDist_29_2477C5804AB8968C0920F8790D819994;      // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                AIMaxAttackDist_30_7148460032C6174A6AF00ED30DEF9994;      // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                BornIslandBulletNum_38_313F40006E88965C3F9EC5D9017AF02D;  // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TArray<int>                                        Lowers_a_51_09824E0023E1D5C00B2140E803435431;             // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<int>                                        Magazines_a_52_6C0D36C00DDFE4CD564FCEC60C50EDD1;          // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<int>                                        Stocks_a_54_62740CC04A4BE64919BB407100C7E4B1;             // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<int>                                        UpperSides_a_56_0CAAB0002CB0CF8444507E9802483CE1;         // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<int>                                        Muzzles_a_57_7CDB4D804CD01C927C17EFF70A0E7CF1;            // 0x0058(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<int>                                        Uppers_a_58_70690EC02BCBD1BF0079F65A02F354E1;             // 0x0068(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<int>                                        Cores_a_59_5B8C8E0066BF188057B2D56F0F3135F1;              // 0x0078(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<int>                                        Bezels_a_60_66A7E8403202AF7557453D6B0A95F3A1;             // 0x0088(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<int>                                        GunLocks_a_61_04C5B88058DB62924278624B0E94B891;           // 0x0098(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<int>                                        TacticalAttachs_a_62_340B6A4003827A8B0B444CAE0952D4B1;    // 0x00A8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

