#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:23:55 2025
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_StatEvent_type.BP_STRUCT_StatEvent_type
// 0x0025
struct FBP_STRUCT_StatEvent_type
{
	struct FString                                     adjustAndroidToken_0_594DE04070C173A163E4B64201910D0E;    // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     adjustIOSToken_1_0503AAC047B9A92166DF565B059ACF0E;        // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                id_2_62C4604044EB8A891315D5090A0F46F4;                    // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               unique_3_5DB792C063488FEF6239807407CF07F5;                // 0x0024(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

