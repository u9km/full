#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:23:55 2025
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_PetDressBlueprintTable_type.BP_STRUCT_PetDressBlueprintTable_type
// 0x0018
struct FBP_STRUCT_PetDressBlueprintTable_type
{
	int                                                Slot_0_31125FC006688BBB2E6646B20FAFCD34;                  // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ID_1_688F3A8033A7814C565560B30E5FAEF4;                    // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     Path_2_51589A804E9002622E9485530FAF46F8;                  // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

