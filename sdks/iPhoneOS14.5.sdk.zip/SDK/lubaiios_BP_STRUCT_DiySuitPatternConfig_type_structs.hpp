#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:23:55 2025
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_DiySuitPatternConfig_type.BP_STRUCT_DiySuitPatternConfig_type
// 0x0048
struct FBP_STRUCT_DiySuitPatternConfig_type
{
	int                                                ID_0_1986288022A4FBB87BF37984018D0894;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     Icon_1_051847804144FD206B0A47070D08B9DE;                  // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ItemID_2_0F4A4C4062CFB54B08ACFC37094B4CD4;                // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
	struct FString                                     BPUrl_3_25D5368039F7AA966A5B00C00083445C;                 // 0x0020(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                Cost_4_22EF0B80079BBB006A2E79840D08E724;                  // 0x0030(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0034(0x0004) MISSED OFFSET
	struct FString                                     Name_5_5103258079CB0E186B3912250D0907B5;                  // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

