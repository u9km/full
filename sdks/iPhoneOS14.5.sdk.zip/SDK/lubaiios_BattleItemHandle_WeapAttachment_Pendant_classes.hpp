#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:24:00 2025
 
namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass BattleItemHandle_WeapAttachment_Pendant.BattleItemHandle_WeapAttachment_Pendant_C
// 0x0000 (0x0450 - 0x0450)
class UBattleItemHandle_WeapAttachment_Pendant_C : public UBattleItemHandle_WeapAttachment_C
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BattleItemHandle_WeapAttachment_Pendant.BattleItemHandle_WeapAttachment_Pendant_C");
		return pStaticClass;
	}

};


}

