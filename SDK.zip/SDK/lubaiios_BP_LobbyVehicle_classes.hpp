#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:24:03 2025
 
namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass BP_LobbyVehicle.BP_LobbyVehicle_C
// 0x0104 (0x0644 - 0x0540)
class ABP_LobbyVehicle_C : public ASTExtraLobbyVehicle
{
public:
	class UBP_VehicleDIYComp_C*                        BP_VehicleDIYComp;                                        // 0x0540(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UBP_Lobby_VehicleLicenseComponent_C*         BP_Lobby_VehicleLicenseComponent;                         // 0x0548(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UVehicleAvatarComponent_BP_C*                VehicleAvatarComponent_BP;                                // 0x0550(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UMaterialInstanceDynamic*                    DMI;                                                      // 0x0558(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UMaterialInstanceDynamic*                    FPPDynamicMat;                                            // 0x0560(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       TailLightParamName;                                       // 0x0568(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       FrontLightParamName;                                      // 0x0570(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       FPPBoostLightParamName;                                   // 0x0578(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                vehicleResId;                                             // 0x0580(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0584(0x0004) MISSED OFFSET
	class UMaterialInstanceDynamic*                    DMI_TailLight;                                            // 0x0588(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UMaterialInstanceDynamic*                    DMI_AdvanceVehicle;                                       // 0x0590(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                HighlightTryTime;                                         // 0x0598(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x059C(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData02[0x50];                                      // 0x059C(0x0050) UNKNOWN PROPERTY: SetProperty BP_LobbyVehicle.BP_LobbyVehicle_C.SkyMotors
	unsigned char                                      UnknownData03[0x50];                                      // 0x05F0(0x0050) UNKNOWN PROPERTY: SetProperty BP_LobbyVehicle.BP_LobbyVehicle_C.SpecialMotors
	int                                                ShowType;                                                 // 0x0640(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_LobbyVehicle.BP_LobbyVehicle_C");
		return pStaticClass;
	}


	void TrySetHighLight(float NewParam, float NewParam1, float NewParam2);
	void SetHighLight(float Invincible, float FreExp, float Speed);
	void SetDMIParam(class UMaterialInstanceDynamic* Target, const struct FName& Name, float Value);
	void GetVehicleMasterPath(int VehicleSkinID, struct FString* MeshBasePath);
	void UserConstructionScript();
};


}

