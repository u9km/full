#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:23:56 2025
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Global_Bp.Global_Bp_C.InitOBSettingData
struct UGlobal_Bp_C_InitOBSettingData_Params
{
	class USettingConfig_C*                            ServerSettingConfig;                                      // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Global_Bp.Global_Bp_C.InitCustomizeSettingData
struct UGlobal_Bp_C_InitCustomizeSettingData_Params
{
	class USettingConfig_C*                            ServerSettingConfig;                                      // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Global_Bp.Global_Bp_C.InitFireGyroSensibilitySettingData
struct UGlobal_Bp_C_InitFireGyroSensibilitySettingData_Params
{
	class USettingConfig_C*                            ServerSettingConfig;                                      // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Global_Bp.Global_Bp_C.MapFromCBToESBH
struct UGlobal_Bp_C_MapFromCBToESBH_Params
{
	class USettingConfig_C*                            SettingConfig;                                            // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Global_Bp.Global_Bp_C.InitMirrorObjMapPickupSetting
struct UGlobal_Bp_C_InitMirrorObjMapPickupSetting_Params
{
	class USettingConfig_C*                            ServerSettingConfig;                                      // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Global_Bp.Global_Bp_C.InitThrowObjMapPickupSetting
struct UGlobal_Bp_C_InitThrowObjMapPickupSetting_Params
{
	class USettingConfig_C*                            ServerSettingConfig;                                      // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Global_Bp.Global_Bp_C.InitDrugMapPickupSetting
struct UGlobal_Bp_C_InitDrugMapPickupSetting_Params
{
	class USettingConfig_C*                            ServerSettingConfig;                                      // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Global_Bp.Global_Bp_C.InitBasicSettingData
struct UGlobal_Bp_C_InitBasicSettingData_Params
{
	class USettingConfig_C*                            ServerSettingConfig;                                      // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Global_Bp.Global_Bp_C.InitPickupSettingData_XT
struct UGlobal_Bp_C_InitPickupSettingData_XT_Params
{
	class USettingConfig_C*                            SettingConfig;                                            // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Global_Bp.Global_Bp_C.InitPickupSettingData
struct UGlobal_Bp_C_InitPickupSettingData_Params
{
	class USettingConfig_C*                            ServerSettingConfig;                                      // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Global_Bp.Global_Bp_C.InitSensibilitySettingData
struct UGlobal_Bp_C_InitSensibilitySettingData_Params
{
	class USettingConfig_C*                            ServerSettingConfig;                                      // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Global_Bp.Global_Bp_C.SetGrenadeDefaultPickValue
struct UGlobal_Bp_C_SetGrenadeDefaultPickValue_Params
{
};

// Function Global_Bp.Global_Bp_C.InitMapFromCBToES
struct UGlobal_Bp_C_InitMapFromCBToES_Params
{
};

// Function Global_Bp.Global_Bp_C.MapFromCBToESGlobal
struct UGlobal_Bp_C_MapFromCBToESGlobal_Params
{
	class USettingConfig_C*                            SettingConfig;                                            // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Global_Bp.Global_Bp_C.MapFromCBToESJK
struct UGlobal_Bp_C_MapFromCBToESJK_Params
{
	class USettingConfig_C*                            SettingConfig;                                            // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Global_Bp.Global_Bp_C.MapFromCBToESVN
struct UGlobal_Bp_C_MapFromCBToESVN_Params
{
	class USettingConfig_C*                            SettingConfig;                                            // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Global_Bp.Global_Bp_C.LoadSettingConfigFromSlot
struct UGlobal_Bp_C_LoadSettingConfigFromSlot_Params
{
};

// Function Global_Bp.Global_Bp_C.SetPostProcessSettings
struct UGlobal_Bp_C_SetPostProcessSettings_Params
{
	int                                                ID;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
	float                                              Time;                                                     // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               isReverse;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               isClosing;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Global_Bp.Global_Bp_C.EventAndroidQuitGame
struct UGlobal_Bp_C_EventAndroidQuitGame_Params
{
};

// Function Global_Bp.Global_Bp_C.Construct
struct UGlobal_Bp_C_Construct_Params
{
};

// Function Global_Bp.Global_Bp_C.RecoverMaxFps
struct UGlobal_Bp_C_RecoverMaxFps_Params
{
};

// Function Global_Bp.Global_Bp_C.ExecuteUbergraph_Global_Bp
struct UGlobal_Bp_C_ExecuteUbergraph_Global_Bp_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

