// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:23:47 2025
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function GeneralNode.GNSharedDelegate.EventTrigger
// (Final, Native, Public, BlueprintCallable)

void UGNSharedDelegate::EventTrigger()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function GeneralNode.GNSharedDelegate.EventTrigger");

	UGNSharedDelegate_EventTrigger_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


}

