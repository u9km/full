#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:23:48 2025
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function SceneCaptureWidgetPlugin.SceneCaptureWidget.SetSceneCaptureCameraActor
struct USceneCaptureWidget_SetSceneCaptureCameraActor_Params
{
	class ASceneCaptureCameraActor*                    InSceneCaptureCameraActor;                                // (Parm, ZeroConstructor, IsPlainOldData)
};

}

