#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:24:00 2025
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BP_Ammo_556mm_PickUp.BP_Ammo_556mm_Pickup_C.UserConstructionScript
struct ABP_Ammo_556mm_Pickup_C_UserConstructionScript_Params
{
};

}

