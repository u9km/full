#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:23:58 2025
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Reconnect_BP.Reconnect_BP_C.Construct
struct UReconnect_BP_C_Construct_Params
{
};

// Function Reconnect_BP.Reconnect_BP_C.ExecuteUbergraph_Reconnect_BP
struct UReconnect_BP_C_ExecuteUbergraph_Reconnect_BP_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

