#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:24:02 2025
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function MotionItem_BP.MotionItem_BP_C.Construct
struct UMotionItem_BP_C_Construct_Params
{
};

// Function MotionItem_BP.MotionItem_BP_C.ExecuteUbergraph_MotionItem_BP
struct UMotionItem_BP_C_ExecuteUbergraph_MotionItem_BP_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

