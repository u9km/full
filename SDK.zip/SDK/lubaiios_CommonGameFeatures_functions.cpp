// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:23:49 2025
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function CommonGameFeatures.ActorRepControlComponent.ToggleGroupedRepControlByUID
// (Native, Public)
// Parameters:
// int64_t                        UID                            (Parm, ZeroConstructor, IsPlainOldData)
// int                            ControlMark                    (Parm, ZeroConstructor, IsPlainOldData)
// int                            RepControlGroup                (Parm, ZeroConstructor, IsPlainOldData)

void UActorRepControlComponent::ToggleGroupedRepControlByUID(int64_t UID, int ControlMark, int RepControlGroup)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CommonGameFeatures.ActorRepControlComponent.ToggleGroupedRepControlByUID");

	UActorRepControlComponent_ToggleGroupedRepControlByUID_Params params;
	params.UID = UID;
	params.ControlMark = ControlMark;
	params.RepControlGroup = RepControlGroup;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CommonGameFeatures.ActorRepControlComponent.ShouldBlockRepByUID
// (Native, Public, Const)
// Parameters:
// int64_t                        UID                            (Parm, ZeroConstructor, IsPlainOldData)
// int                            RepControlGroup                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UActorRepControlComponent::ShouldBlockRepByUID(int64_t UID, int RepControlGroup)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CommonGameFeatures.ActorRepControlComponent.ShouldBlockRepByUID");

	UActorRepControlComponent_ShouldBlockRepByUID_Params params;
	params.UID = UID;
	params.RepControlGroup = RepControlGroup;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CommonGameFeatures.ActorRepControlComponent.GetControlGroupData
// (Final, Native, Public, HasOutParms, Const)
// Parameters:
// int                            RepControlGroup                (Parm, ZeroConstructor, IsPlainOldData)
// struct FRepControlGroupData    OutData                        (Parm, OutParm)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UActorRepControlComponent::GetControlGroupData(int RepControlGroup, struct FRepControlGroupData* OutData)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CommonGameFeatures.ActorRepControlComponent.GetControlGroupData");

	UActorRepControlComponent_GetControlGroupData_Params params;
	params.RepControlGroup = RepControlGroup;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (OutData != nullptr)
		*OutData = params.OutData;

	return params.ReturnValue;
}


// Function CommonGameFeatures.RepControlActorBase.IsNetRelevantForCustomCheck
// (Native, Event, Public, HasOutParms, HasDefaults, BlueprintEvent, Const)
// Parameters:
// class AActor*                  RealViewer                     (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class AActor*                  ViewTarget                     (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 SrcLocation                    (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ARepControlActorBase::IsNetRelevantForCustomCheck(class AActor* RealViewer, class AActor* ViewTarget, const struct FVector& SrcLocation)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CommonGameFeatures.RepControlActorBase.IsNetRelevantForCustomCheck");

	ARepControlActorBase_IsNetRelevantForCustomCheck_Params params;
	params.RealViewer = RealViewer;
	params.ViewTarget = ViewTarget;
	params.SrcLocation = SrcLocation;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


}

