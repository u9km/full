#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:23:48 2025
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct KantanChartsDatasource.KantanCartesianDatapoint
// 0x0008
struct FKantanCartesianDatapoint
{
	struct FVector2D                                   Coords;                                                   // 0x0000(0x0008) (Edit, BlueprintVisible, IsPlainOldData)
};

}

