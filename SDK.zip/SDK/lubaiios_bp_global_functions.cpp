// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:23:55 2025
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function bp_global.bp_global_C.EventShowPlatWXStartup_NoFetch
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventShowPlatWXStartup_NoFetch()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventShowPlatWXStartup_NoFetch");

	Abp_global_C_EventShowPlatWXStartup_NoFetch_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventShowPlatWXStartup
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventShowPlatWXStartup()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventShowPlatWXStartup");

	Abp_global_C_EventShowPlatWXStartup_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventShowPlatQQStartup_NoFetch
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventShowPlatQQStartup_NoFetch()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventShowPlatQQStartup_NoFetch");

	Abp_global_C_EventShowPlatQQStartup_NoFetch_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventShowPlatQQStartup
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventShowPlatQQStartup()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventShowPlatQQStartup");

	Abp_global_C_EventShowPlatQQStartup_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventShowPlatIconTips_NoFetch
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventShowPlatIconTips_NoFetch()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventShowPlatIconTips_NoFetch");

	Abp_global_C_EventShowPlatIconTips_NoFetch_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventShowPlatIconTips
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventShowPlatIconTips()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventShowPlatIconTips");

	Abp_global_C_EventShowPlatIconTips_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventSetInfo_Push_NoFetch
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventSetInfo_Push_NoFetch()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventSetInfo_Push_NoFetch");

	Abp_global_C_EventSetInfo_Push_NoFetch_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventSetInfo_Push
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventSetInfo_Push()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventSetInfo_Push");

	Abp_global_C_EventSetInfo_Push_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventSendClickGemReport_NoFetch
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventSendClickGemReport_NoFetch()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventSendClickGemReport_NoFetch");

	Abp_global_C_EventSendClickGemReport_NoFetch_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventSendClickGemReport
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventSendClickGemReport()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventSendClickGemReport");

	Abp_global_C_EventSendClickGemReport_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventSendBAReport_NoFetch
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventSendBAReport_NoFetch()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventSendBAReport_NoFetch");

	Abp_global_C_EventSendBAReport_NoFetch_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventSendBAReport
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventSendBAReport()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventSendBAReport");

	Abp_global_C_EventSendBAReport_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventGlobalUseItem_NoFetch
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventGlobalUseItem_NoFetch()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventGlobalUseItem_NoFetch");

	Abp_global_C_EventGlobalUseItem_NoFetch_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventGlobalUseItem
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventGlobalUseItem()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventGlobalUseItem");

	Abp_global_C_EventGlobalUseItem_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventGlobalCloseItemTips_NoFetch
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventGlobalCloseItemTips_NoFetch()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventGlobalCloseItemTips_NoFetch");

	Abp_global_C_EventGlobalCloseItemTips_NoFetch_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventGlobalCloseItemTips
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventGlobalCloseItemTips()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventGlobalCloseItemTips");

	Abp_global_C_EventGlobalCloseItemTips_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventFetchNationSwitch_NoFetch
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventFetchNationSwitch_NoFetch()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventFetchNationSwitch_NoFetch");

	Abp_global_C_EventFetchNationSwitch_NoFetch_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventFetchNationSwitch
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventFetchNationSwitch()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventFetchNationSwitch");

	Abp_global_C_EventFetchNationSwitch_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventFetchInfo_NoFetch
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventFetchInfo_NoFetch()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventFetchInfo_NoFetch");

	Abp_global_C_EventFetchInfo_NoFetch_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventFetchInfo
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventFetchInfo()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventFetchInfo");

	Abp_global_C_EventFetchInfo_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventComMsgBoxSluaClickUrl_NoFetch
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventComMsgBoxSluaClickUrl_NoFetch()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventComMsgBoxSluaClickUrl_NoFetch");

	Abp_global_C_EventComMsgBoxSluaClickUrl_NoFetch_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventComMsgBoxSluaClickUrl
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventComMsgBoxSluaClickUrl()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventComMsgBoxSluaClickUrl");

	Abp_global_C_EventComMsgBoxSluaClickUrl_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventClickLobbyEventGemReport_NoFetch
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventClickLobbyEventGemReport_NoFetch()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventClickLobbyEventGemReport_NoFetch");

	Abp_global_C_EventClickLobbyEventGemReport_NoFetch_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventClickLobbyEventGemReport
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventClickLobbyEventGemReport()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventClickLobbyEventGemReport");

	Abp_global_C_EventClickLobbyEventGemReport_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventCheckIfMenuOpen_NoFetch
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventCheckIfMenuOpen_NoFetch()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventCheckIfMenuOpen_NoFetch");

	Abp_global_C_EventCheckIfMenuOpen_NoFetch_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventCheckIfMenuOpen
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventCheckIfMenuOpen()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventCheckIfMenuOpen");

	Abp_global_C_EventCheckIfMenuOpen_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventAndroidQuitGame_NoFetch
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventAndroidQuitGame_NoFetch()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventAndroidQuitGame_NoFetch");

	Abp_global_C_EventAndroidQuitGame_NoFetch_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.EventAndroidQuitGame
// (BlueprintCallable, BlueprintEvent)

void Abp_global_C::EventAndroidQuitGame()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.EventAndroidQuitGame");

	Abp_global_C_EventAndroidQuitGame_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function bp_global.bp_global_C.UserConstructionScript
// (Event, Public, BlueprintCallable, BlueprintEvent)

void Abp_global_C::UserConstructionScript()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function bp_global.bp_global_C.UserConstructionScript");

	Abp_global_C_UserConstructionScript_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


}

