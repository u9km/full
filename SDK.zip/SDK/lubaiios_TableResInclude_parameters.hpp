#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:23:47 2025
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function TableResInclude.EvoBaseMapUIMarkTableMap.TraversTable
struct UEvoBaseMapUIMarkTableMap_TraversTable_Params
{
	class UUAEDataTable*                               TableData;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       Key;                                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function TableResInclude.EvoBaseModTableTestTableMap.TraversTable
struct UEvoBaseModTableTestTableMap_TraversTable_Params
{
	class UUAEDataTable*                               TableData;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       Key;                                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

}

