#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:23:58 2025
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_RegionNo_type.BP_STRUCT_RegionNo_type
// 0x0008
struct FBP_STRUCT_RegionNo_type
{
	int                                                country_0_3B96D2C060DA453F186EAF900DC8C429;               // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                region_1_1913AEC0609F05AD760068620AD117AE;                // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

