#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:24:01 2025
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Lobby_Mid_Banner_Dot_Item.Lobby_Mid_Banner_Dot_Item_C.SetData
struct ULobby_Mid_Banner_Dot_Item_C_SetData_Params
{
	bool                                               bSelect;                                                  // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

