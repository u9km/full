#pragma once

// SDK -- lubaiios 
// TG - @ALBAsTool @LBAsTool 
// 生成时间 11/5 18:23:58 2025
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_PickUpCountSetting_type.BP_STRUCT_PickUpCountSetting_type
// 0x0008
struct FBP_STRUCT_PickUpCountSetting_type
{
	int                                                ItemID_0_545B594077C2AB55279AB97B0BD162B4;                // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                PickUpMaxCount_1_7F45D10069EF87FA21D7CBCA0C4BDCD4;        // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

